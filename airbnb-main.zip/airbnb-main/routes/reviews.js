const express = require('express');
const router = express.Router({ mergeParams: true });
const listingmodel = require("../models/listing.js");
const reviewmodel = require("../models/review.js");
const wrapAsync = require("../utils/wrapAsync.js");
const ExpressError = require("../utils/ExpressError.js");
const {validateReview, isLoggedIn, isReviewAuthor} = require("../middleware.js");
const reviewController = require("../controllers/reviews.js");









//reviews
//post a review route
router.post('/',isLoggedIn, validateReview, wrapAsync(reviewController.createReview));

//delete a review route
router.delete('/:reviewId',isLoggedIn, isReviewAuthor, wrapAsync(reviewController.destroyReview));

module.exports = router;