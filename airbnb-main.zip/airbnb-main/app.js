if(process.envnNODE_ENV != "production"){
  require('dotenv').config();
}

// console.log(process.env.secret) // remove this after you've confirmed it is working

var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const mongoose = require('mongoose');
const methodOverride = require("method-override");
const ejsMate = require("ejs-mate");
const session = require("express-session");
const MongoStore = require('connect-mongo');
const flash = require("connect-flash")
const passport = require('passport');
const localStrategy = require("passport-local");
const user = require("./models/user.js");
const ExpressError = require("./utils/ExpressError.js");




var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
const listingsRouter = require('./routes/listings.js');
const reviewsRouter = require('./routes/reviews.js');

// const { session } = require('passport');

var app = express();




const dbUrl = process.env.ATLASDB_URL;
// mongoose.connect("mongodb://127.0.0.1:27017/wanderlust")
mongoose.connect(dbUrl)
.then(() => {
    console.log("connected to ATLAS DB");
  })
  .catch(() => {
    console.log(err);
  });


  

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(methodOverride("_method"));
app.engine('ejs', ejsMate);




//session part start

const store = MongoStore.create({
  mongoUrl: dbUrl,
  crypto: {
    secret: process.env.SECRET,
  },
  touchAfter: 24*3600,
});

store.on("error", () => {
  console.log("ERROR IN MONGO SESSION STORE", err);
});

const sessionOptions = {
  store: store,
  secret: process.env.SECRET,
  resave: false,
  saveUninitialized: true,
  cookie: {
    expires: Date.now() + 7 * 24 * 60 * 60 * 1000,
    maxAge: 7 * 24 * 60 * 60 * 1000,
    httpOnly: true
  },
};




app.use(session(sessionOptions));
app.use(flash())   //routes nu app.use karta pahela flash nu app.use karvu padse. flash setup karva npm i karya pachi require karyu and pach aa aap.use karyu.//


    //passport no code.(passport session no pn use karse so ahi lakhyu che)//
app.use(passport.initialize());
app.use(passport.session());
passport.use(new localStrategy(user.authenticate()));

passport.serializeUser(user.serializeUser());
passport.deserializeUser(user.deserializeUser());

      // passport no code complete//

app.use((req, res, next) =>{
  res.locals.success = req.flash("success");
  res.locals.error = req.flash("error");
  res.locals.currUser = req.user;
  next();
});

//session part end


app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/listings', listingsRouter);
app.use('/listings/:id/reviews', reviewsRouter);



// apna clg err handling
app.all("*", (req, res, next) => {
  next(new ExpressError(404,"page Not Found"));
});

app.use((err, req, res, next) => {
  let{statusCode = 500, message="something went wrong"} = err;
  res.status(statusCode).render("error.ejs", {message});
});
//error handling complete




module.exports = app;



